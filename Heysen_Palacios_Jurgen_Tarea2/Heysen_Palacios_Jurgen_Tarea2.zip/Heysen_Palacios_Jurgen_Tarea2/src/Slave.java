/**
 * Clase que modela los subditos del Boss
 * @author Jurgen
 * @version 0.0.1
 * No hacen mucho como entidad, pero su IA es de cuidado
 *
 */
public class Slave extends Entity{

}
